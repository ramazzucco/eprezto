import React, { Component } from 'react';
import Polizas from './components/polizas/index';

export default class App extends Component {
  render() {
    return (
      <Polizas />
    )
  }
}
