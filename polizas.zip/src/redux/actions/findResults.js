export const type = 'findResults';

const findResults = () => {
    return {
        type,
        payload: [],
    };
}

export default findResults;